#!/system/bin/sh
# =================================================================
# Pure Shell Game Booster (Non-Root Version)
# CPU/GPU Render Optimization for Gaming
# =================================================================

BOOST_MODE="gaming"
CPU_THRESHOLD=70
GPU_BOOST_LEVEL=85
CHECK_INTERVAL=10

# Performance flags - accessible without root
setprop debug.hwui.renderer skiagl 2>/dev/null
setprop debug.renderengine.backend skiaglthreaded 2>/dev/null
setprop debug.hwui.use_hint_manager true 2>/dev/null
setprop debug.sf.enable_adpf_cpu_hint true 2>/dev/null
setprop debug.hwui.target_cpu_time_percent 85 2>/dev/null
setprop debug.sf.latch_unsignaled 1 2>/dev/null
setprop debug.choreographer.skipwarning 1 2>/dev/null

# GPU optimization
setprop debug.egl.hw 1 2>/dev/null
setprop debug.composition.type gpu 2>/dev/null
setprop persist.sys.ui.hw 1 2>/dev/null
setprop ro.config.enable.hw_accel true 2>/dev/null

echo "=== Game Booster Started ==="
echo "Mode: $BOOST_MODE"
echo "CPU Threshold: ${CPU_THRESHOLD}%"
echo "GPU Boost: ${GPU_BOOST_LEVEL}%"

# Get system info
get_cpu_cores() {
    cores=$(grep -c ^processor /proc/cpuinfo 2>/dev/null)
    [ -z "$cores" ] || [ "$cores" -eq 0 ] && cores=4
    echo "$cores"
}

get_cpu_usage() {
    if [ -r /proc/stat ]; then
        read cpu u n s i w x y z < /proc/stat
        total1=$((u + n + s + i + w + x + y + z))
        idle1=$((i + w))
        
        sleep 0.2
        
        read cpu u n s i w x y z < /proc/stat
        total2=$((u + n + s + i + w + x + y + z))
        idle2=$((i + w))
        
        diff_total=$((total2 - total1))
        diff_idle=$((idle2 - idle1))
        
        [ "$diff_total" -eq 0 ] && { echo 50; return; }
        
        usage=$((100 * (diff_total - diff_idle) / diff_total))
        echo "$usage"
    else
        echo 50
    fi
}

get_memory_usage() {
    if [ -r /proc/meminfo ]; then
        total=$(awk '/MemTotal:/ {print $2}' /proc/meminfo)
        avail=$(awk '/MemAvailable:/ {print $2}' /proc/meminfo)
        [ -z "$total" ] || [ "$total" -eq 0 ] && { echo 50; return; }
        used=$((total - avail))
        percent=$((100 * used / total))
        echo "$percent"
    else
        echo 50
    fi
}

apply_gaming_boost() {
    cpu_load=$(get_cpu_usage)
    mem_load=$(get_memory_usage)
    
    # Dynamic CPU boost
    if [ "$cpu_load" -gt "$CPU_THRESHOLD" ]; then
        target_cpu=$CPU_THRESHOLD
    else
        target_cpu=$cpu_load
    fi
    
    # Apply boost (clamped between 60-95)
    boost_level=$((target_cpu + 15))
    [ "$boost_level" -lt 60 ] && boost_level=60
    [ "$boost_level" -gt 95 ] && boost_level=95
    
    setprop debug.hwui.target_cpu_time_percent "$boost_level" 2>/dev/null
    
    # GPU rendering boost
    if [ "$cpu_load" -gt 60 ]; then
        setprop debug.hwui.render_thread_count 4 2>/dev/null
        setprop debug.hwui.use_buffer_age false 2>/dev/null
    else
        setprop debug.hwui.render_thread_count 2 2>/dev/null
        setprop debug.hwui.use_buffer_age true 2>/dev/null
    fi
    
    echo "[$(date +%H:%M:%S)] CPU:${cpu_load}% MEM:${mem_load}% BOOST:${boost_level}%"
}

optimize_thermal() {
    # Try to read thermal zones (non-root readable on some devices)
    for zone in /sys/class/thermal/thermal_zone*/temp; do
        if [ -r "$zone" ]; then
            temp=$(cat "$zone" 2>/dev/null)
            if [ -n "$temp" ] && [ "$temp" -gt 60000 ]; then
                # Reduce boost if thermal throttling detected
                setprop debug.hwui.target_cpu_time_percent 70 2>/dev/null
                echo "[THERMAL] High temp detected, reducing boost"
                return
            fi
        fi
    done
}

# Detect active games (common game package patterns)
detect_game() {
    # Check for common gaming processes
    ps_out=$(ps -A 2>/dev/null | grep -iE 'game|unity|unreal|genshin|pubg|freefire|codm|mlbb|wildrift' | grep -v grep)
    
    if [ -n "$ps_out" ]; then
        echo "[GAME] Gaming session detected"
        return 0
    else
        return 1
    fi
}

# Cleanup function
cleanup() {
    echo ""
    echo "=== Restoring Normal Mode ==="
    setprop debug.hwui.target_cpu_time_percent 0 2>/dev/null
    setprop debug.hwui.render_thread_count 0 2>/dev/null
    setprop debug.hwui.use_buffer_age true 2>/dev/null
    echo "Game Booster stopped."
    exit 0
}

trap cleanup TERM INT HUP QUIT

# Main monitoring loop
num_cores=$(get_cpu_cores)
echo "CPU Cores: $num_cores"
echo "Optimization engine started..."
echo "Press Ctrl+C to stop"
echo ""

counter=0
while true; do
    apply_gaming_boost
    
    # Check thermal every 5 cycles
    counter=$((counter + 1))
    if [ "$((counter % 5))" -eq 0 ]; then
        optimize_thermal
    fi
    
    # Auto-detect games every 10 cycles
    if [ "$((counter % 10))" -eq 0 ]; then
        if detect_game; then
            setprop debug.hwui.target_cpu_time_percent "$GPU_BOOST_LEVEL" 2>/dev/null
        fi
    fi
    
    sleep "$CHECK_INTERVAL"
done